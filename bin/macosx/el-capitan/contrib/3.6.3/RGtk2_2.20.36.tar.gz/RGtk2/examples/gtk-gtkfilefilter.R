filter <- gtkFileFilter()
filter$addPattern("*")
