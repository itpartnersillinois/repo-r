## Pressing Alt-H will activate this button
button <- gtkButton()
label <- gtkLabelNewWithMnemonic("_Hello")
button$add(label)
