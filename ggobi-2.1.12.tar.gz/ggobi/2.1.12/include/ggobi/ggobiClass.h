#include "tsdisplay.h"
#include "parcoordsClass.h"
#include "barchartDisplay.h"
#include "scatterplotClass.h"
#include "scatmatClass.h"


void registerDisplayTypes(GTypeLoad *loaders, int n);
